﻿namespace zSckinCareBookingService
{
	public class Class1
	{

	}
}
