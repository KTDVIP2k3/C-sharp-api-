﻿namespace SP25_NET1718_RPR231_ASM1_SE173443_KhanhTD
{
	public class Class1
	{

	}
}
